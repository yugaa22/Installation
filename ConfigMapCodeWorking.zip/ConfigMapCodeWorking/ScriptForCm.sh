#!/bin/bash

                echo "Enter NAMESPACE For Installation of HAlYARD"
                read ns
		kubectl create ns $ns

		echo "Enter minioConfigMap file"
                read miniocm              
                kubectl create -f $miniocm -n $ns

                echo "Enter HAlYARDConfigMap file"
                read halcm
		kubectl create -f $halcm -n $ns

                echo "Enter KUBEConfigMap file"
                read kubecm
                kubectl create cm kubeconfig --from-file $kubecm -n $ns
				
                echo "Enter Template of HAlYARD"
                read haltemp
                kubectl create -f $halyardtemp -n $ns
                pod=`(kubectl get pods -n $ns | grep spin-halyard | awk '{print $1}')`
                sleep 60
                kubectl exec -it $pod  -n $ns bash hal deploy apply
	echo "done"
        echo "Wait for 8-10 min to All Spinnaker pods are Up and Running"
        echo "To check that RUN  ' watch kubectl get pods -n $ns '"
:'
#run these in three diffrent new terminal 
#Terminal 1
sudo ssh -i <<PATH TO .PEM>> -L 9008:localhost:9008  <<USERNAME>>@<<IP>>
kubectl port-forward minio-deployment-5cf4d6dcbf-bt94j 9008:9000 -n cms

#Terminal 2
sudo ssh -i <<PATH TO .PEM>> -L 8084:localhost:8084  <<USERNAME>>@<<IP>>
kubectl port-forward spin-gate-8d8df54bd-84cjc 8084:8084 -n cms

#Terminal 3
sudo ssh -i <<PATH TO .PEM>> -L 9000:localhost:9000  <<USERNAME>>@<<IP>>
kubectl port-forward spin-deck-79d64b895f-264wd 9000:9000 -n cms
 '
echo "You can Access spinnaker in UI by localhost:9000 "
