#!/bin/bash


echo "Enter Minio-Access-key to Install Minio"
read ACCESS_KEY
echo "Enter Minio-Secret-key to Install Minio"
read SECRET_KEY
sed -i "s/ACCESSKEY/$ACCESS_KEY/" minio.yml
sed -i "s/SECRETKEY/$SECRET_KEY/" minio.yml

#Installing kubectl
curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.14.0/bin/linux/amd64/kubectl 
chmod +x ./kubectl 
sudo mv ./kubectl /usr/local/bin/kubectl
#Please Place The KubeConfig file inthe path .kube/config
echo "Enter Namespace"
read ns
kubectl create namespace $ns

sudo kubectl config set-context $(kubectl config current-context) --namespace=$ns

kubectl  -n $ns apply -f minio.yml
kubectl -n $ns apply -f halyard.yml
echo "Wait For 60 Seconds to Halyard pod Get Up"
sleep 60
pod=`(kubectl get pods -n $ns | grep spin-halyard | awk '{print $1}')`
kubectl -n $ns cp profiles $pod:/tmp/profiles
kubectl -n $ns cp Part2.sh $pod:/tmp/Part2.sh
kubectl -n $ns  cp ~/.kube/config $pod:/tmp/kubeconfig 
kubectl -n $ns exec -it $pod -- bash -c "bash /tmp/Part2.sh $ns " && \
echo "Spinnaker Installation Over"
echo "Wait For 8-10 min for all spinnaker pods getting up and Runnig"


