#!/bin/bash

hal config provider kubernetes enable && \
echo "Enter K8s-Account name"    && \
read K8s_Account    && \
hal config provider kubernetes account add $K8s_Account --provider-version v2  --kubeconfig-file /tmp/kubeconfig  && \
hal config deploy edit --type Distributed --account-name $K8s_Account --location $1 && \
mkdir -p /home/spinnaker/.hal/defalut/profiles && \
touch /home/spinnaker/.hal/defalut/profiles/front50-local.yml  && \
echo "spinnaker.s3.versioning: false" > /home/spinnaker/.hal/defalut/profiles/front50-local.yml && \
echo "Enter Minio Access-key" && \
read ACCESS_KEY && \
hal config storage s3 edit --endpoint http://minio-service:9000 --access-key-id $ACCESS_KEY --secret-access-key && \
hal config storage s3 edit --path-style-access=true && \
hal config storage edit --type s3  && \
hal config version edit --version $(hal version latest -q)  && \
hal deploy apply

